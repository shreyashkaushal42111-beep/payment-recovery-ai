"""
predict.py
Demo: given a new failed transaction, predict retry success probability
and recommend the best hour to retry.
"""

import pandas as pd
import joblib

model = joblib.load("/home/claude/payment-recovery-ai/src/retry_model.pkl")
encoders = joblib.load("/home/claude/payment-recovery-ai/src/encoders.pkl")

feature_cols = [
    "amount", "payment_method_enc", "failure_reason_enc",
    "hour_of_day", "day_of_week", "customer_retry_count_past",
    "is_repeat_customer",
]

def predict_retry(amount, payment_method, failure_reason, hour_of_day,
                   day_of_week, customer_retry_count_past, is_repeat_customer):
    row = pd.DataFrame([{
        "amount": amount,
        "payment_method_enc": encoders["payment_method"].transform([payment_method])[0],
        "failure_reason_enc": encoders["failure_reason"].transform([failure_reason])[0],
        "hour_of_day": hour_of_day,
        "day_of_week": day_of_week,
        "customer_retry_count_past": customer_retry_count_past,
        "is_repeat_customer": is_repeat_customer,
    }])
    prob = model.predict_proba(row[feature_cols])[0, 1]
    return round(prob, 3)

if __name__ == "__main__":
    # Example: a failed UPI payment due to network timeout, repeat customer
    example = dict(
        amount=1200,
        payment_method="upi",
        failure_reason="network_timeout",
        hour_of_day=14,
        day_of_week=3,
        customer_retry_count_past=1,
        is_repeat_customer=1,
    )
    prob = predict_retry(**example)
    print(f"Transaction: {example}")
    print(f"Predicted retry success probability: {prob*100:.1f}%")

    if prob >= 0.6:
        print("Recommendation: Auto-retry now.")
    elif prob >= 0.4:
        print("Recommendation: Retry later (check best_retry_recommendations.csv for optimal hour).")
    else:
        print("Recommendation: Send reminder / alternate payment link instead of auto-retry.")
