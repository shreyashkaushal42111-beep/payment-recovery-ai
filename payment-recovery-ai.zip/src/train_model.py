"""
train_model.py
Trains a classifier that predicts whether retrying a failed payment
will succeed, and finds the best retry hour for each failure type.
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report, roc_auc_score
import joblib

df = pd.read_csv("/home/claude/payment-recovery-ai/data/failed_transactions.csv")

# Encode categorical columns
encoders = {}
for col in ["payment_method", "failure_reason"]:
    le = LabelEncoder()
    df[col + "_enc"] = le.fit_transform(df[col])
    encoders[col] = le

feature_cols = [
    "amount", "payment_method_enc", "failure_reason_enc",
    "hour_of_day", "day_of_week", "customer_retry_count_past",
    "is_repeat_customer",
]

X = df[feature_cols]
y = df["retry_success"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

model = RandomForestClassifier(n_estimators=200, max_depth=8, random_state=42)
model.fit(X_train, y_train)

preds = model.predict(X_test)
probs = model.predict_proba(X_test)[:, 1]

print("=== Model Performance ===")
print(classification_report(y_test, preds))
print("ROC-AUC:", round(roc_auc_score(y_test, probs), 3))

print("\n=== Feature Importance ===")
importance = pd.Series(model.feature_importances_, index=feature_cols).sort_values(ascending=False)
print(importance)

# Save model + encoders for reuse
joblib.dump(model, "/home/claude/payment-recovery-ai/src/retry_model.pkl")
joblib.dump(encoders, "/home/claude/payment-recovery-ai/src/encoders.pkl")

# ---- Best retry hour recommendation per failure reason ----
print("\n=== Best Retry Hour per Failure Reason (avg predicted success) ===")
results = []
for reason in df["failure_reason"].unique():
    reason_enc = encoders["failure_reason"].transform([reason])[0]
    best_hour, best_score = None, -1
    for hour in range(24):
        sample = pd.DataFrame([{
            "amount": df["amount"].mean(),
            "payment_method_enc": df["payment_method_enc"].mode()[0],
            "failure_reason_enc": reason_enc,
            "hour_of_day": hour,
            "day_of_week": 2,
            "customer_retry_count_past": 1,
            "is_repeat_customer": 1,
        }])
        score = model.predict_proba(sample[feature_cols])[0, 1]
        if score > best_score:
            best_score, best_hour = score, hour
    results.append((reason, best_hour, round(best_score, 3)))

result_df = pd.DataFrame(results, columns=["failure_reason", "best_retry_hour", "predicted_success_prob"])
result_df = result_df.sort_values("predicted_success_prob", ascending=False)
print(result_df.to_string(index=False))
result_df.to_csv("/home/claude/payment-recovery-ai/data/best_retry_recommendations.csv", index=False)
