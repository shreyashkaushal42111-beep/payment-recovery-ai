"""
generate_data.py
Generates synthetic failed-payment transaction data to simulate
a Razorpay-like payment recovery dataset.
"""

import pandas as pd
import numpy as np

np.random.seed(42)

N = 3000  # number of failed transactions to simulate

failure_reasons = [
    "insufficient_funds",
    "bank_server_error",
    "card_expired",
    "network_timeout",
    "otp_failed",
    "issuer_declined",
]

payment_methods = ["credit_card", "debit_card", "upi", "netbanking", "wallet"]

data = {
    "transaction_id": [f"TXN{100000+i}" for i in range(N)],
    "amount": np.round(np.random.exponential(scale=1500, size=N) + 50, 2),
    "payment_method": np.random.choice(payment_methods, N, p=[0.25, 0.25, 0.30, 0.15, 0.05]),
    "failure_reason": np.random.choice(failure_reasons, N,
                                        p=[0.28, 0.18, 0.10, 0.20, 0.14, 0.10]),
    "hour_of_day": np.random.randint(0, 24, N),
    "day_of_week": np.random.randint(0, 7, N),   # 0=Mon
    "customer_retry_count_past": np.random.poisson(1.2, N),
    "is_repeat_customer": np.random.choice([0, 1], N, p=[0.4, 0.6]),
}

df = pd.DataFrame(data)

# ---- Simulate a "ground truth" retry-success label ----
# Certain conditions make a retry more likely to succeed. This mimics
# real-world patterns (e.g. network/OTP issues recover well on retry,
# insufficient funds recovers better later at night/salary days, etc.)
def simulate_success(row):
    score = 0.3  # base probability

    if row["failure_reason"] in ["network_timeout", "bank_server_error"]:
        score += 0.35
    if row["failure_reason"] == "otp_failed":
        score += 0.25
    if row["failure_reason"] == "insufficient_funds":
        score -= 0.15
    if row["failure_reason"] == "card_expired":
        score -= 0.30

    if row["is_repeat_customer"] == 1:
        score += 0.10

    if row["customer_retry_count_past"] >= 3:
        score -= 0.15

    if row["payment_method"] == "upi":
        score += 0.10

    # best retry hours: late evening / early morning (less network load)
    if row["hour_of_day"] in [21, 22, 23, 0, 1, 6, 7]:
        score += 0.10

    score = np.clip(score + np.random.normal(0, 0.12), 0, 1)
    return np.random.binomial(1, score)

df["retry_success"] = df.apply(simulate_success, axis=1)

df.to_csv("/home/claude/payment-recovery-ai/data/failed_transactions.csv", index=False)
print("Generated dataset:", df.shape)
print(df["retry_success"].value_counts(normalize=True))
